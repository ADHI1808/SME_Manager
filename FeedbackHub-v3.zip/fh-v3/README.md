# Feedback Hub — Complete Full Stack Project

**Structured Feedback Platform for Training Programs**
Spring Boot 3.2 Backend + Angular 17 Frontend

---

## Quick Start

### Backend
```bash
cd backend
# Import as Maven project in Eclipse (File → Import → Maven → Existing Maven Projects)
# Select the 'backend' folder (which contains pom.xml directly)
# Run As → Spring Boot App
```

### Frontend
```bash
cd frontend
npm install
ng serve
# Open: http://localhost:4200
```

---

## Demo Login Credentials

| Role    | Email            | Password |
|---------|------------------|----------|
| Trainer | trainer@fh.com   | password |
| Trainee | ravi@fh.com      | password |
| Trainee | divya@fh.com     | password |

---

## Project Structure

```
FeedbackHub-Complete/
├── backend/                         ← Spring Boot (import THIS folder in Eclipse)
│   ├── pom.xml
│   └── src/main/java/com/feedbackhub/
│       ├── FeedbackHubApplication.java
│       ├── config/          SecurityConfig.java, DataSeeder.java
│       ├── controller/      AuthController, ScoreController, FeedbackController,
│       │                    AlertController, DashboardController
│       ├── dto/             AuthDto, ScoreDto, FeedbackDto, AlertDto,
│       │                    DashboardDto, UserDto, ActivityLogDto
│       ├── entity/          User, Score, FeedbackThread, SkillAlert, ActivityLog
│       ├── enums/           UserRole, AlertLevel, FeedbackStatus, TrendDirection
│       ├── exception/       ResourceNotFoundException, GlobalExceptionHandler
│       ├── repository/      UserRepository, ScoreRepository, FeedbackThreadRepository,
│       │                    SkillAlertRepository, ActivityLogRepository
│       ├── security/        JwtService, JwtAuthFilter, CustomUserDetailsService
│       └── service/         AuthService, ScoreService, FeedbackService,
│                            SkillAlertService, DashboardService, ActivityLogService
│
└── frontend/                        ← Angular 17 (npm install && ng serve)
    └── src/app/
        ├── core/
        │   ├── guards/      auth.guard.ts
        │   ├── interceptors/ jwt.interceptor.ts
        │   └── services/    auth.service.ts, api.services.ts
        ├── shared/
        │   ├── models/      index.ts (all TypeScript interfaces)
        │   └── components/  score-badge, loading-spinner
        ├── layout/          main-layout (sidebar + topbar shell)
        └── features/
            ├── auth/        login
            ├── trainer/     dashboard, upload, pods, directory, activity
            └── trainee/     dashboard, scorecards, feedback, alerts, cohort
```

---

## API Endpoints

| Method | URL | Role | Description |
|--------|-----|------|-------------|
| POST | /auth/login | Public | Login |
| POST | /auth/register | Public | Register |
| GET | /trainer/dashboard | TRAINER | Trainer stats |
| POST | /trainer/scores | TRAINER | Add score |
| POST | /trainer/scores/bulk | TRAINER | Bulk upload Excel/CSV |
| GET | /trainer/scores | TRAINER | My uploaded scores |
| GET | /trainee/dashboard | TRAINEE | Trainee stats |
| GET | /scores/trainee/{id} | Any | Scores for trainee |
| GET | /feedback/score/{id} | Any | Feedback thread |
| POST | /feedback | Any | Add message |
| GET | /trainee/alerts/{id} | TRAINEE | Skill alerts |
| PATCH | /trainee/alerts/{id}/acknowledge | TRAINEE | Acknowledge alert |
| PATCH | /trainee/alerts/{id}/resolve | TRAINEE | Resolve alert |

---

## Key Design Decisions

| Decision | Choice | Reason |
|----------|--------|--------|
| No Lombok | Plain Java getters/setters | Works in Eclipse without plugin |
| @Autowired | Field injection | No circular dependency issues |
| CustomUserDetailsService | Separate @Service | Breaks SecurityConfig ↔ JwtAuthFilter cycle |
| ApplicationContext for AuthManager | Lazy fetch | Avoids null AuthenticationManager |
| H2 in-memory | Dev database | Zero config, swap to MySQL for prod |
| Auto-alert trigger | Score < 65% → SkillAlert | Automated per FR-E4 |
| Bulk upload (Apache POI) | Excel/CSV import | FR-T2 requirement |
