package com.feedbackhub.repository;

import com.feedbackhub.entity.FeedbackThread;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FeedbackThreadRepository extends JpaRepository<FeedbackThread, Long> {
    List<FeedbackThread> findByScoreIdOrderByCreatedAtAsc(Long scoreId);
    List<FeedbackThread> findBySenderEmailOrderByCreatedAtDesc(String email);
}
