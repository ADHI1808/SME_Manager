package com.feedbackhub.repository;

import com.feedbackhub.entity.Score;
import com.feedbackhub.entity.User;
import com.feedbackhub.enums.FeedbackStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ScoreRepository extends JpaRepository<Score, Long> {

    List<Score> findByTraineeOrderBySubmittedDateDesc(User trainee);

    List<Score> findByTrainerOrderBySubmittedDateDesc(User trainer);

    @Query("SELECT AVG(s.score) FROM Score s WHERE s.trainee = :trainee")
    Optional<Double> findAvgScoreByTrainee(@Param("trainee") User trainee);

    @Query("SELECT AVG(s.score) FROM Score s WHERE s.trainee.podName = :pod")
    Optional<Double> findAvgScoreByPod(@Param("pod") String pod);

    @Query("SELECT s FROM Score s WHERE s.trainee.podName = :pod ORDER BY s.submittedDate DESC")
    List<Score> findByPod(@Param("pod") String pod);

    long countByTraineeAndFeedbackStatus(User trainee, FeedbackStatus status);

    List<Score> findByTraineeOrderBySubmittedDateDesc(User trainee, Pageable pageable);
}
