package com.feedbackhub.repository;

import com.feedbackhub.entity.SkillAlert;
import com.feedbackhub.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SkillAlertRepository extends JpaRepository<SkillAlert, Long> {
    List<SkillAlert> findByTraineeOrderByCreatedAtDesc(User trainee);
    List<SkillAlert> findByTraineeAndAcknowledgedFalseOrderByCreatedAtDesc(User trainee);
    long countByTraineeAndAcknowledgedFalse(User trainee);
    long countByTraineeAndResolvedTrue(User trainee);
}
