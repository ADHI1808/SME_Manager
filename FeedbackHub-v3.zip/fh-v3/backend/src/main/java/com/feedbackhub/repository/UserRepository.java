package com.feedbackhub.repository;
import com.feedbackhub.entity.User;
import com.feedbackhub.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User>     findByRole(UserRole role);
    List<User>     findByPodName(String podName);
    List<User>     findByCohortName(String cohortName);

    @Query("SELECT u FROM User u WHERE u.role = 'TRAINEE' ORDER BY u.cohortName, u.podName, u.fullName")
    List<User> findAllTraineesOrdered();

    @Query("SELECT DISTINCT u.cohortName FROM User u WHERE u.cohortName IS NOT NULL")
    List<String> findDistinctCohorts();

    @Query("SELECT DISTINCT u.podName FROM User u WHERE u.podName IS NOT NULL")
    List<String> findDistinctPods();
}
